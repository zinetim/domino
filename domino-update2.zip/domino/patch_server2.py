import re

# ---------------- game.py: seçimsiz çəkiliş artıq qəbul olunmur ----------------
g = open('game.py', encoding='utf-8').read()
assert 'picks' in g, "Əvvəlcə patch_server.py işlədilməlidir (game.py-da picks yoxdur)"
old = "idx = list(range(len(self.market) - k, len(self.market)))"
if old in g:
    g = g.replace(old, 'return "Yeni versiya var — səhifəni yeniləyin (bazardan daşı özünüz seçirsiniz)"', 1)
    open('game.py', 'w', encoding='utf-8').write(g)
    print("game.py OK")
else:
    print("game.py: artıq tətbiq olunub")

# ---------------- app.py: versiya + səhifə ----------------
a = open('app.py', encoding='utf-8').read()
if 'BUILD' not in a:
    assert 'import hashlib' not in a
    a = a.replace('import os\n', 'import hashlib\nimport os\n', 1)
    a = a.replace('from flask import Flask, jsonify, request, send_from_directory',
                  'from flask import Flask, Response, jsonify, request, send_from_directory', 1)
    new_index = '''def _page():
    with open(os.path.join(app.root_path, "templates", "index.html"), encoding="utf-8") as f:
        html = f.read()
    b = hashlib.md5(html.encode("utf-8")).hexdigest()[:8]
    return html.replace("__BUILD__", b), b


PAGE, BUILD = _page()


@app.route("/")
def index():
    return Response(PAGE, mimetype="text/html", headers={"Cache-Control": "no-store"})


@sio.on("connect")
def on_connect(auth=None):
    emit("build", BUILD)
'''
    a2, n = re.subn(r'@app\.route\("/"\)\ndef index\(\):.*?return r\n', lambda m: new_index, a, count=1, flags=re.S)
    assert n == 1, "app.py: index marşrutu tapılmadı"
    open('app.py', 'w', encoding='utf-8').write(a2)
    print("app.py OK")
else:
    print("app.py: artıq tətbiq olunub")
